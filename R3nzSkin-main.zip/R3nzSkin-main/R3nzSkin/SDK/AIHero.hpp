#pragma once

#include "AIBaseCommon.hpp"

class AIHero : public AIBaseCommon {
public:
};
