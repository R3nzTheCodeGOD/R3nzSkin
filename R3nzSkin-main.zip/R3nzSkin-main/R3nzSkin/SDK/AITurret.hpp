#pragma once

#include "AIBaseCommon.hpp"

class AITurret : public AIBaseCommon {
public:
};
